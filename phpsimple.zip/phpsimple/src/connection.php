<?php
	require("constants.php");
	// $mysqli = new mysqli("phpsimple-db-1", "root", "1234", "userlistdb");
    $mysqli = new mysqli("appDB", "user", "password", "userlistdb");

	// mysql_select_db(DB_NAME) or die("Cannot select DB");
	// $result = $mysqli->query("SELECT * FROM users");
    
	?>