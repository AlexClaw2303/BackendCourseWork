<?php
session_name('inSystem');
session_start();
?>

<!DOCTYPE html>
<html>

<head>
<title>РСЧИР</title>
  <link rel="stylesheet" href="protected/style.css">
  <style>
    ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
      overflow: hidden;
      background-color: #333;
    }

    li {
      float: left;
    }

    li a {
      display: block;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }

    li a:hover:not(.active) {
      background-color: #22baba;
    }

    .active {
      background-color: #04AA6D;
    }

    .active:hover {
      background-color: #22baba;
    }

    .active_logout {
      background-color: #a11616;
    }
  </style>
</head>
<body class="mainpagebody">
  <ul>
    <li><a href="mainpage.php">Мои тесты</a></li>
    <li style="float:right"><a class="active_logout" href="logout.php">Выйти</a></li>
    <li style="float:right"><a class="active" href="">
        <?php
        $email = $_SESSION['session_username'];
        echo $email;
        ?></a></li>
  </ul>
  <div id="tgraf-iframe-box-119748"></div>
  <script type="text/javascript" src="https://www.testograf.ru/widgets-files/iframe_119748_49c7346187.js" ></script>
  <script type="text/javascript" src="https://www.testograf.ru/scripts/iframe_resizer.min.js"></script>
<script type="text/javascript">testograf.iframe_resizer.resize(500);</script>
</body>
</html>